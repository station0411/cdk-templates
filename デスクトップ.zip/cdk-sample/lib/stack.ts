import { Stack, StackProps } from 'aws-cdk-lib';
import { Role, ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';

export class SampleStack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    new Role(this, 'IamRole', {
      roleName: 'cdk-sample-role',
      assumedBy: new ServicePrincipal('ec2.amazonaws.com'),
    });
  }
}
