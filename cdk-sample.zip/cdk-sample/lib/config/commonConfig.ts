export default {
  resourceNamePrefix: 'xxx-yyy-zzz',
  azList: ['ap-northeast-1a', 'ap-northeast-1c'],
}