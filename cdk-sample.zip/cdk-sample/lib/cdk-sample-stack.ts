import { Stack, StackProps, Tags } from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import resourceConfig from './config/resourceConfig';
import commonConfig from './config/commonConfig';

export class CdkSampleStack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    // VPCの作成
    const vpc = new ec2.CfnVPC(this, `${commonConfig.resourceNamePrefix}-vpc`, {
      cidrBlock: resourceConfig.vpc.cidr,
      enableDnsHostnames: true,
      enableDnsSupport: true
    });
    Tags.of(vpc).add('Name', `${commonConfig.resourceNamePrefix}-vpc`);

    // サブネットとルートテーブルをセットで作成
    for (const [subnetKey, subnetDefs] of Object.entries(resourceConfig.subnet)) {
      subnetDefs.forEach((subnetDef, index) => {
        // サブネットの作成
        const subnet = new ec2.CfnSubnet(this, `${commonConfig.resourceNamePrefix}-subnet-${subnetKey}-${index}`, {
          vpcId: vpc.ref,
          availabilityZone: subnetDef.az,
          cidrBlock: subnetDef.cidr
        });
        Tags.of(subnet).add('Name', `${commonConfig.resourceNamePrefix}-subnet-${subnetKey}-${index}`);

        // ルートテーブルの作成
        const routeTable = new ec2.CfnRouteTable(this, `${commonConfig.resourceNamePrefix}-routetable-${subnetKey}-${index}`, {
          vpcId: vpc.ref,
        });
        Tags.of(routeTable).add('Name', `${commonConfig.resourceNamePrefix}-routetable-${subnetKey}-${index}`);

        // サブネットとルートテーブルの関連付け
        new ec2.CfnSubnetRouteTableAssociation(this, `${commonConfig.resourceNamePrefix}-association-subnet-routetable-${subnetKey}-${index}`, {
          subnetId: subnet.ref,
          routeTableId: routeTable.ref,
        });
      });
    }
  }
}