import os
import subprocess

COMMAND_FILE = ".\\commands.txt"
ERROR_LOG = ".\\error_log.txt"
OUTPUT_DIR = ".\\output"
# SUCCESS_LOG = ".\\new_commands.txt"

# 出力ディレクトリ作成
os.makedirs(OUTPUT_DIR, exist_ok=True)

# コマンド読み込み
with open(COMMAND_FILE, "r", encoding="utf-8") as f:
    commands = [line.strip() for line in f if line.strip()]

for command in commands:
    print(f"Running: {command}")

    # ファイル名の決定
    try:
        parts = command.split()
        service = parts[1]
        action = parts[2]
        output_file = f"{OUTPUT_DIR}\\{service}_{action}.json"
    except IndexError:
        with open(ERROR_LOG, "a", encoding="utf-8") as err:
            err.write(f"[Invalid format] {command}\n\n")
        continue

    # 実行
    result = subprocess.run(
        command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="cp932",
        errors="replace"
    )

    # 成功・失敗の処理
    if result.returncode == 0 and result.stdout.strip():
        with open(output_file, "w", encoding="utf-8") as out:
            out.write(result.stdout)
        # with open(SUCCESS_LOG, "a", encoding="utf-8") as log:
        #     log.write(command + "\n")
    else:
        with open(ERROR_LOG, "a", encoding="utf-8") as err:
            err.write(f"[{command}]\n")
            err.write(result.stderr + "\n\n")
